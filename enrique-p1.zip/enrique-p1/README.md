# project1

This a a simple portfolio project from the Udacity Front-End Web Development nanodegree. The goal was to create a basic portfolio page with responsive page characteristics.
